# AI Application Compiler

> Natural language → **Intent → Design → Schemas → Validation → Repair → Runtime**.
> A modular, compiler-style pipeline (not a chatbot) that turns a one-line
> product description into validated, executable JSON configs for a real app:
> UI schema, API schema, SQLite DB schema, and Auth schema.

---

## Architecture

```text
                ┌───────────────────────────────────────────────────────┐
                │                       FastAPI                         │
                │  POST /generate { prompt }  ──►  full pipeline JSON   │
                └────────────────────────────┬──────────────────────────┘
                                             │
                                ┌────────────▼────────────┐
                                │      orchestrator.py    │
                                └────────────┬────────────┘
                                             │
   ┌────────────────┬──────────────┬─────────┴─────────┬──────────────┬────────────────┐
   ▼                ▼              ▼                   ▼              ▼                ▼
 Intent          System         Schema Gen         Validator       Repair          Runtime
 Extractor       Designer       (UI/API/DB/Auth)   (Pydantic +     Engine          Simulator
                                                    cross-layer)   (surgical)      (SQLite)
   │                │                │                  │              │                │
   └─ Pydantic ─────┴─ Pydantic ─────┴─ Pydantic ───────┴─ logs ───────┴─ PASS/FAIL ────┘
```

Every stage lives in its **own module**:

| File | Responsibility |
|---|---|
| `pipeline/intent_extractor.py` | App type, features, entities, roles |
| `pipeline/system_designer.py`  | Pages, relationships, flows |
| `pipeline/schema_generator.py` | Four independent generators (UI/API/DB/Auth) |
| `pipeline/validator.py`        | Pydantic + cross-layer consistency checks |
| `pipeline/repair_engine.py`    | Surgical, per-error repairs (no blind regenerate) |
| `pipeline/runtime_simulator.py`| In-memory SQLite materialization + endpoint check |
| `pipeline/llm_client.py`       | OpenAI / Gemini wrapper (`temperature=0`) |
| `pipeline/stub_llm.py`         | Offline deterministic fallback so the system runs without an API key |
| `orchestrator.py`              | Glues stages + repair loop (up to 3 attempts) |
| `main.py`                      | FastAPI app, `/generate`, static frontend |

Schemas (Pydantic) are in `schemas/`:
`intent_schema.py`, `design_schema.py`, `ui_schema.py`, `api_schema.py`,
`db_schema.py`, `auth_schema.py`.

---

## Pipeline explanation

1. **Intent Extraction** – classifies app type, extracts entities, roles,
   features, and explicit assumptions for vague prompts.
2. **System Design** – derives pages, relationships, and user flows.
3. **Schema Generation** – four *independent* LLM calls produce DB, API,
   UI, and Auth schemas. They are never collapsed into a single prompt.
4. **Validation** – Pydantic structural validation + cross-layer rules:
   - API entities ⊆ DB tables
   - UI `action.api` ∈ API endpoint ids
   - UI `component.entity` ∈ DB tables
   - Auth rule resources ∈ API ids, roles ∈ Auth roles
   - DB PK & FK integrity, SQL type whitelist
5. **Repair Engine** – inspects each validation error and applies a
   **targeted** fix (add missing PK, drop dangling action, create missing
   table, add missing role, …). Only the offending layer is touched.
   Up to 3 repair iterations.
6. **Runtime Simulation** – creates the schema in an in-memory SQLite DB
   (topologically ordering FKs), seeds one row per table, exercises each
   `GET` endpoint, and checks every UI/Auth reference. Returns
   `{"status": "PASS"}` or a list of runtime errors.

---

## Validation strategy

- **Pydantic** enforces field types, enums, and required keys at construction
  time — malformed LLM output cannot even reach the validator.
- The validator is *defensive*: every layer is re-validated and a set of
  cross-layer invariants is checked. The full list of checks is reported
  in `validation.checks`.

## Repair strategy

The repair engine is intentionally **surgical**:

| Error | Repair |
|---|---|
| `missing_pk` | Inject `id INTEGER PRIMARY KEY` |
| `bad_type` | Coerce unknown SQL type → `TEXT` |
| `bad_fk` | Drop invalid foreign-key reference |
| `entity_missing_in_db` | Auto-create the missing table |
| `action_api_missing` | Remove dangling UI action |
| `component_entity_missing` | Create missing entity table |
| `role_missing` | Add missing auth role |
| `rule_resource_missing` | Drop dangling auth rule |

Every change is recorded in `repair_logs[]`.

## Runtime simulation

- Tables are created in dependency order against `:memory:` SQLite.
- One synthetic row is inserted per table using sensible per-type defaults.
- For each `GET` endpoint, a `SELECT * FROM <entity> LIMIT 1` is executed
  to prove the API ↔ DB binding is real.
- Auth rules and UI references are verified against the live in-memory
  schema.

---

## Setup

```bash
cd ai-compiler
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

# Optional - pick ONE provider:
export OPENAI_API_KEY=sk-...
# or
export GEMINI_API_KEY=...

# If neither is set, the deterministic offline stub LLM is used so the
# pipeline still produces realistic, validated schemas.

uvicorn main:app --reload --port 8000
```

Open <http://localhost:8000>.

### API

```bash
curl -X POST localhost:8000/generate \
  -H 'content-type: application/json' \
  -d '{"prompt":"Build a CRM with login and leads management."}' | jq
```

Response:

```json
{
  "intent": { ... },
  "design": { ... },
  "ui_schema": { ... },
  "api_schema": { ... },
  "db_schema": { ... },
  "auth_schema": { ... },
  "validation": {"errors": [], "warnings": [], "checks": [...]},
  "repair_logs": [...],
  "runtime_results": {"status": "PASS", "errors": [], "details": {...}},
  "metrics": {"retries": 0, "repair_count": 0,
              "latency_ms": 123, "validation_ok": true,
              "runtime_status": "PASS"}
}
```

---

## Evaluation framework

`evaluation/dataset.json` ships 10 normal prompts and 10 edge cases
(vague, conflicting, oversized, missing-entity). Run:

```bash
python -m evaluation.run_eval
```

Reports per-prompt and aggregate metrics:

- success rate (validation passes)
- runtime pass rate
- total retries / repairs
- average latency

## Tests

```bash
python tests/test_pipeline.py
```

---

## Deployment

Any host that runs Python + Uvicorn works:

```bash
uvicorn main:app --host 0.0.0.0 --port 8000 --workers 2
```

Container: a 5-line `Dockerfile` based on `python:3.11-slim`,
`pip install -r requirements.txt`, `CMD ["uvicorn", ...]`.

---

## Design notes / non-goals

- **Determinism:** every LLM call uses `temperature=0` and JSON-mode where
  available.
- **No giant prompts:** four independent generators keep each stage
  focused; failures repair locally instead of cascading.
- **Offline mode:** `pipeline/stub_llm.py` keeps the system honest in CI —
  the *exact same* validator + repair + runtime path runs whether the
  LLM is GPT, Gemini, or the stub.
