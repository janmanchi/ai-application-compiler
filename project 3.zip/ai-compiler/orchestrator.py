"""Pipeline orchestrator.

Runs all stages in order and applies the repair loop (up to N attempts)
until validation passes or budget exhausted, then runs the runtime
simulator. Returns the full structured result.
"""
from __future__ import annotations
import time
from typing import Dict, Any

from pipeline.intent_extractor import extract_intent
from pipeline.system_designer import design_system
from pipeline.schema_generator import (
    generate_api, generate_db, generate_ui, generate_auth)
from pipeline.validator import validate_all
from pipeline.repair_engine import repair
from pipeline.runtime_simulator import simulate


MAX_REPAIR_ATTEMPTS = 3


def run_pipeline(prompt: str) -> Dict[str, Any]:
    t0 = time.time()
    metrics: Dict[str, Any] = {"retries": 0, "repair_count": 0}

    # --- Stage 1 ---
    intent = extract_intent(prompt)
    # --- Stage 2 ---
    design = design_system(intent)
    # --- Stage 3: schema generation (DB first, then API, then UI, then Auth)
    db = generate_db(design)
    api = generate_api(design)
    ui = generate_ui(design, api)
    auth = generate_auth(intent, api)

    # --- Stage 4 + 5: validate / repair loop ---
    all_logs = []
    report = validate_all(design, ui, api, db, auth)
    attempts = 0
    while report["errors"] and attempts < MAX_REPAIR_ATTEMPTS:
        attempts += 1
        metrics["retries"] = attempts
        design, ui, api, db, auth, logs = repair(
            design, ui, api, db, auth, report["errors"])
        all_logs.extend(logs)
        metrics["repair_count"] += len(logs)
        report = validate_all(design, ui, api, db, auth)

    # --- Stage 6 ---
    runtime = simulate(ui, api, db, auth)

    metrics["latency_ms"] = int((time.time() - t0) * 1000)
    metrics["validation_ok"] = not report["errors"]
    metrics["runtime_status"] = runtime["status"]

    return {
        "intent": intent.model_dump(),
        "design": design.model_dump(),
        "ui_schema": ui.model_dump(),
        "api_schema": api.model_dump(),
        "db_schema": db.model_dump(),
        "auth_schema": auth.model_dump(),
        "validation": report,
        "repair_logs": all_logs,
        "runtime_results": runtime,
        "metrics": metrics,
    }
