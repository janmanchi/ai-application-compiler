"""FastAPI entry point."""
from __future__ import annotations
from pathlib import Path
from fastapi import FastAPI
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from orchestrator import run_pipeline

ROOT = Path(__file__).parent

app = FastAPI(title="AI Application Compiler",
              description="Natural language -> validated app schemas",
              version="1.0.0")

app.mount("/static", StaticFiles(directory=str(ROOT / "static")), name="static")


class GenerateRequest(BaseModel):
    prompt: str = Field(..., min_length=5, max_length=4000)


@app.get("/", response_class=HTMLResponse)
def index() -> HTMLResponse:
    return HTMLResponse((ROOT / "templates" / "index.html").read_text())


@app.post("/generate")
def generate(req: GenerateRequest) -> JSONResponse:
    try:
        result = run_pipeline(req.prompt)
        return JSONResponse(result)
    except Exception as e:  # pragma: no cover - defensive
        return JSONResponse(
            {"error": str(e), "type": e.__class__.__name__},
            status_code=500,
        )


@app.get("/health")
def health() -> dict:
    return {"status": "ok"}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=False)
