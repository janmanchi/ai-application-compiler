"""Pydantic models for the Intent Extraction stage."""
from __future__ import annotations
from typing import List, Optional
from pydantic import BaseModel, Field


class Role(BaseModel):
    name: str
    permissions: List[str] = Field(default_factory=list)


class Entity(BaseModel):
    name: str
    description: Optional[str] = ""
    attributes: List[str] = Field(default_factory=list)


class Intent(BaseModel):
    app_type: str
    app_name: str
    features: List[str] = Field(default_factory=list)
    entities: List[Entity] = Field(default_factory=list)
    roles: List[Role] = Field(default_factory=list)
    business_requirements: List[str] = Field(default_factory=list)
    assumptions: List[str] = Field(default_factory=list)
    open_questions: List[str] = Field(default_factory=list)
