"""Pydantic models for the Auth Schema."""
from __future__ import annotations
from typing import List, Literal
from pydantic import BaseModel, Field


class AuthRole(BaseModel):
    name: str
    permissions: List[str] = Field(default_factory=list)


class AuthRule(BaseModel):
    resource: str       # API endpoint id or path
    allowed_roles: List[str]


class AuthSchema(BaseModel):
    method: Literal["jwt", "session", "oauth2", "none"] = "jwt"
    providers: List[str] = Field(default_factory=lambda: ["email_password"])
    roles: List[AuthRole]
    rules: List[AuthRule] = Field(default_factory=list)
