"""Pydantic models for the DB Schema."""
from __future__ import annotations
from typing import List, Optional, Literal
from pydantic import BaseModel, Field


SQL_TYPES = {"INTEGER", "TEXT", "REAL", "BOOLEAN", "DATETIME", "BLOB"}


class Column(BaseModel):
    name: str
    type: str  # SQLite type
    primary_key: bool = False
    nullable: bool = True
    unique: bool = False
    default: Optional[str] = None
    references: Optional[str] = None  # "table.column"


class Table(BaseModel):
    name: str
    columns: List[Column]


class DBSchema(BaseModel):
    dialect: Literal["sqlite"] = "sqlite"
    tables: List[Table]
