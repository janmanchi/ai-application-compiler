"""Pydantic models for the System Design stage."""
from __future__ import annotations
from typing import List, Optional
from pydantic import BaseModel, Field


class Page(BaseModel):
    name: str
    route: str
    description: Optional[str] = ""
    requires_auth: bool = False
    allowed_roles: List[str] = Field(default_factory=list)


class Relationship(BaseModel):
    from_entity: str
    to_entity: str
    type: str  # one_to_one | one_to_many | many_to_many


class Flow(BaseModel):
    name: str
    steps: List[str]


class Design(BaseModel):
    architecture: str = "client-server-rest"
    pages: List[Page]
    entities: List[str]
    relationships: List[Relationship] = Field(default_factory=list)
    flows: List[Flow] = Field(default_factory=list)
