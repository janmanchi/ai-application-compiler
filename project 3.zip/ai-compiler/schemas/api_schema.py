"""Pydantic models for the API Schema."""
from __future__ import annotations
from typing import List, Optional, Literal, Dict
from pydantic import BaseModel, Field


class APIParam(BaseModel):
    name: str
    type: str
    required: bool = True
    location: Literal["body", "query", "path", "header"] = "body"


class APIEndpoint(BaseModel):
    id: str
    method: Literal["GET", "POST", "PUT", "DELETE", "PATCH"]
    path: str
    description: Optional[str] = ""
    entity: Optional[str] = None
    params: List[APIParam] = Field(default_factory=list)
    response_fields: List[str] = Field(default_factory=list)
    auth_required: bool = False
    allowed_roles: List[str] = Field(default_factory=list)


class APISchema(BaseModel):
    base_url: str = "/api"
    endpoints: List[APIEndpoint]
