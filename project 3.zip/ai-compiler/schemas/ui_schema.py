"""Pydantic models for the UI Schema."""
from __future__ import annotations
from typing import List, Optional, Literal
from pydantic import BaseModel, Field


class UIField(BaseModel):
    name: str
    label: str
    type: Literal["text", "email", "password", "number", "date", "textarea",
                  "select", "checkbox", "boolean"]
    required: bool = False
    options: List[str] = Field(default_factory=list)


class UIAction(BaseModel):
    label: str
    api: str   # references API endpoint id
    method: Literal["GET", "POST", "PUT", "DELETE", "PATCH"] = "POST"


class UIComponent(BaseModel):
    id: str
    type: Literal["form", "table", "list", "detail", "card", "nav"]
    title: Optional[str] = ""
    fields: List[UIField] = Field(default_factory=list)
    actions: List[UIAction] = Field(default_factory=list)
    entity: Optional[str] = None  # which DB entity it maps to


class UIPage(BaseModel):
    name: str
    route: str
    components: List[UIComponent] = Field(default_factory=list)


class UISchema(BaseModel):
    pages: List[UIPage]
