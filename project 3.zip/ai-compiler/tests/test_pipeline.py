"""Smoke tests covering the full pipeline using the offline stub LLM."""
from __future__ import annotations
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from orchestrator import run_pipeline


def test_crm_pipeline():
    r = run_pipeline("Build a CRM with leads, admin, and login.")
    assert r["intent"]["app_type"] == "crm"
    assert any(e["name"] == "lead" for e in r["intent"]["entities"])
    assert r["validation"]["errors"] == []
    assert r["runtime_results"]["status"] == "PASS"


def test_ecommerce_pipeline():
    r = run_pipeline("Build an e-commerce store with products and orders.")
    assert r["intent"]["app_type"] == "ecommerce"
    tables = {t["name"] for t in r["db_schema"]["tables"]}
    assert "product" in tables and "order" in tables and "user" in tables
    assert r["runtime_results"]["status"] == "PASS"


def test_vague_prompt_assumptions():
    r = run_pipeline("Build something cool.")
    # vague prompts should still produce a valid pipeline
    assert r["intent"]["assumptions"]
    assert r["validation"]["errors"] == []


if __name__ == "__main__":
    test_crm_pipeline(); print("ok crm")
    test_ecommerce_pipeline(); print("ok ecommerce")
    test_vague_prompt_assumptions(); print("ok vague")
