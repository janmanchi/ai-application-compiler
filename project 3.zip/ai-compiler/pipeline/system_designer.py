"""Stage 2: System Design."""
from __future__ import annotations
import json
from .llm_client import complete_json
from schemas.intent_schema import Intent
from schemas.design_schema import Design

SYSTEM = """[STAGE:DESIGN]
You are the System Design stage of an AI application compiler.
Given the extracted intent, produce a system design as STRICT JSON:

{
  "architecture": "client-server-rest",
  "pages":    [{"name": "...", "route": "/...", "description": "...",
                "requires_auth": true|false, "allowed_roles": ["..."]}],
  "entities": ["..."],
  "relationships": [{"from_entity": "...", "to_entity": "...",
                     "type": "one_to_one|one_to_many|many_to_many"}],
  "flows":    [{"name": "...", "steps": ["...", "..."]}]
}

Rules:
- Output ONLY JSON.
- Every entity from the intent MUST appear in "entities".
- Provide at least a Login page and one List + Detail page per entity.
- Routes must be lowercase, no trailing slash.
"""


def design_system(intent: Intent) -> Design:
    payload = {"intent": intent.model_dump()}
    raw = complete_json(SYSTEM, json.dumps(payload))
    return Design(**raw)
