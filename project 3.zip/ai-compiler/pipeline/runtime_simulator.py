"""Stage 6: Runtime Simulator.

Materializes the DB schema into an in-memory SQLite database, inserts a
few synthetic rows for each table, and then exercises a representative
sample of API endpoints by simulating their SQL behaviour. Also checks
auth rules and UI references.
"""
from __future__ import annotations
import sqlite3
from typing import Dict, Any, List

from schemas.ui_schema import UISchema
from schemas.api_schema import APISchema
from schemas.db_schema import DBSchema
from schemas.auth_schema import AuthSchema


def _ddl(table) -> str:
    cols = []
    for c in table.columns:
        parts = [f'"{c.name}"', c.type]
        if c.primary_key:
            parts.append("PRIMARY KEY")
            if c.type.upper() == "INTEGER":
                parts.append("AUTOINCREMENT")
        if not c.nullable and not c.primary_key:
            parts.append("NOT NULL")
        if c.unique and not c.primary_key:
            parts.append("UNIQUE")
        if c.default is not None:
            parts.append(f"DEFAULT {c.default}")
        cols.append(" ".join(parts))
    for c in table.columns:
        if c.references:
            ft, fc = c.references.split(".", 1)
            cols.append(f'FOREIGN KEY("{c.name}") REFERENCES "{ft}"("{fc}")')
    return f'CREATE TABLE "{table.name}" ({", ".join(cols)})'


def simulate(ui: UISchema, api: APISchema, db: DBSchema,
             auth: AuthSchema) -> Dict[str, Any]:
    results: Dict[str, Any] = {"db": {}, "api": {}, "auth": {}, "ui": {}}
    errors: List[str] = []

    # --- DB ---
    # SQLite needs FK targets created first; order by topology.
    conn = sqlite3.connect(":memory:")
    conn.execute("PRAGMA foreign_keys=ON")
    cur = conn.cursor()
    ordered: List = []
    remaining = list(db.tables)
    created = set()
    safety = 0
    while remaining and safety < 100:
        safety += 1
        progress = False
        for t in list(remaining):
            deps = {c.references.split(".")[0] for c in t.columns
                    if c.references}
            if deps.issubset(created):
                ordered.append(t)
                created.add(t.name)
                remaining.remove(t)
                progress = True
        if not progress:
            # break the cycle: append remaining ignoring FKs
            ordered.extend(remaining)
            for t in remaining:
                created.add(t.name)
            remaining = []
    for t in ordered:
        try:
            cur.execute(_ddl(t))
            results["db"][t.name] = "created"
        except Exception as e:
            results["db"][t.name] = f"error: {e}"
            errors.append(f"DB:{t.name}:{e}")

    # --- seed a row per table ---
    for t in db.tables:
        try:
            insert_cols = [c for c in t.columns
                           if not c.primary_key and c.default is None]
            names = ", ".join(f'"{c.name}"' for c in insert_cols)
            qs = ", ".join("?" for _ in insert_cols)
            vals = []
            for c in insert_cols:
                up = c.type.upper()
                if up == "INTEGER":
                    vals.append(1)
                elif up == "REAL":
                    vals.append(1.0)
                elif up == "BOOLEAN":
                    vals.append(0)
                elif up == "DATETIME":
                    vals.append("2025-01-01 00:00:00")
                elif up == "BLOB":
                    vals.append(b"x")
                else:
                    vals.append(f"seed_{c.name}")
            if insert_cols:
                cur.execute(f'INSERT INTO "{t.name}" ({names}) VALUES ({qs})', vals)
            else:
                cur.execute(f'INSERT INTO "{t.name}" DEFAULT VALUES')
        except Exception as e:
            errors.append(f"SEED:{t.name}:{e}")

    conn.commit()

    # --- API ---
    db_tables = {t.name: {c.name for c in t.columns} for t in db.tables}
    for ep in api.endpoints:
        info = {"method": ep.method, "path": ep.path, "status": "ok"}
        if ep.entity and ep.entity not in db_tables:
            info["status"] = f"error: entity {ep.entity} missing"
            errors.append(f"API:{ep.id}:{info['status']}")
        else:
            # exercise GET endpoints with a SELECT
            if ep.method == "GET" and ep.entity:
                try:
                    cur.execute(f'SELECT * FROM "{ep.entity}" LIMIT 1')
                    row = cur.fetchone()
                    info["sample_row"] = row
                except Exception as e:
                    info["status"] = f"error: {e}"
                    errors.append(f"API:{ep.id}:{e}")
        results["api"][ep.id] = info

    # --- Auth ---
    api_ids = {ep.id for ep in api.endpoints}
    role_names = {r.name for r in auth.roles}
    for rule in auth.rules:
        ok = (rule.resource in api_ids
              and all(r in role_names for r in rule.allowed_roles))
        results["auth"][rule.resource] = "ok" if ok else "invalid"
        if not ok:
            errors.append(f"AUTH:{rule.resource}:invalid")

    # --- UI ---
    for p in ui.pages:
        for c in p.components:
            ref_ok = all(a.api in api_ids for a in c.actions)
            ent_ok = (c.entity is None) or (c.entity in db_tables)
            ok = ref_ok and ent_ok
            results["ui"][f"{p.route}#{c.id}"] = "ok" if ok else "invalid"
            if not ok:
                errors.append(f"UI:{p.route}#{c.id}:invalid")

    conn.close()
    return {
        "status": "PASS" if not errors else "FAIL",
        "errors": errors,
        "details": results,
    }
