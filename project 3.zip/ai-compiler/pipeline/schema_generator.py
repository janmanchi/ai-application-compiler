"""Stage 3: Schema Generation. Splits into UI / API / DB / Auth."""
from __future__ import annotations
import json
from .llm_client import complete_json
from schemas.intent_schema import Intent
from schemas.design_schema import Design
from schemas.ui_schema import UISchema
from schemas.api_schema import APISchema
from schemas.db_schema import DBSchema
from schemas.auth_schema import AuthSchema


UI_SYSTEM = """[STAGE:UI]
You generate the UI Schema. Return STRICT JSON:
{"pages":[{"name":"...","route":"/...","components":[
  {"id":"...","type":"form|table|list|detail|card|nav","title":"...",
   "entity":"...","fields":[{"name":"...","label":"...",
   "type":"text|email|password|number|date|textarea|select|checkbox|boolean",
   "required":true,"options":[]}],
   "actions":[{"label":"...","api":"<api_endpoint_id>","method":"POST"}]}]}]}
Every action.api MUST reference an existing api endpoint id.
Output ONLY JSON."""

API_SYSTEM = """[STAGE:API]
You generate the API Schema. Return STRICT JSON:
{"base_url":"/api","endpoints":[{"id":"snake_case_id","method":"GET|POST|PUT|DELETE|PATCH",
"path":"/...","description":"...","entity":"...",
"params":[{"name":"...","type":"...","required":true,"location":"body|query|path|header"}],
"response_fields":["..."],"auth_required":true,"allowed_roles":["admin","user"]}]}
Every entity field referenced MUST correspond to a DB column.
Output ONLY JSON."""

DB_SYSTEM = """[STAGE:DB]
You generate the SQLite DB Schema. Return STRICT JSON:
{"dialect":"sqlite","tables":[{"name":"...","columns":[
  {"name":"id","type":"INTEGER","primary_key":true,"nullable":false,
   "unique":true,"default":null,"references":null}]}]}
Allowed SQL types: INTEGER, TEXT, REAL, BOOLEAN, DATETIME, BLOB.
Every table MUST have an integer primary key 'id'.
Foreign keys use "table.column" in 'references'.
Output ONLY JSON."""

AUTH_SYSTEM = """[STAGE:AUTH]
You generate the Auth Schema. Return STRICT JSON:
{"method":"jwt","providers":["email_password"],
 "roles":[{"name":"admin","permissions":["read","write","delete"]}],
 "rules":[{"resource":"<api_endpoint_id>","allowed_roles":["admin"]}]}
Every rule.resource MUST reference an existing API endpoint id, and every
role in rules MUST exist in roles[]. Output ONLY JSON."""


def generate_ui(design: Design, api_schema: APISchema) -> UISchema:
    payload = {"design": design.model_dump(),
               "api_schema": api_schema.model_dump()}
    raw = complete_json(UI_SYSTEM, json.dumps(payload))
    return UISchema(**raw)


def generate_api(design: Design) -> APISchema:
    payload = {"design": design.model_dump()}
    raw = complete_json(API_SYSTEM, json.dumps(payload))
    return APISchema(**raw)


def generate_db(design: Design) -> DBSchema:
    payload = {"design": design.model_dump()}
    raw = complete_json(DB_SYSTEM, json.dumps(payload))
    return DBSchema(**raw)


def generate_auth(intent: Intent, api_schema: APISchema) -> AuthSchema:
    payload = {"intent": intent.model_dump(),
               "api_schema": api_schema.model_dump()}
    raw = complete_json(AUTH_SYSTEM, json.dumps(payload))
    return AuthSchema(**raw)
