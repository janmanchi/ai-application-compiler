"""LLM client wrapper.

Provides a single `complete_json(system, user)` function that hides the
specifics of OpenAI vs Gemini. Always uses temperature=0 for determinism.

Set either:
    OPENAI_API_KEY  (uses model gpt-4o-mini by default)
    GEMINI_API_KEY  (uses gemini-1.5-flash by default)

If neither key is present, falls back to a deterministic heuristic stub
so the pipeline still runs end-to-end in offline / CI environments.
"""
from __future__ import annotations
import json
import os
import re
from typing import Any, Dict

try:
    from openai import OpenAI  # type: ignore
except Exception:  # pragma: no cover
    OpenAI = None  # type: ignore

try:
    import google.generativeai as genai  # type: ignore
except Exception:  # pragma: no cover
    genai = None  # type: ignore


PROVIDER = None
_client = None


def _init() -> None:
    global PROVIDER, _client
    if PROVIDER is not None:
        return
    if os.getenv("OPENAI_API_KEY") and OpenAI is not None:
        PROVIDER = "openai"
        _client = OpenAI()
    elif os.getenv("GEMINI_API_KEY") and genai is not None:
        PROVIDER = "gemini"
        genai.configure(api_key=os.getenv("GEMINI_API_KEY"))
        _client = genai.GenerativeModel(
            os.getenv("GEMINI_MODEL", "gemini-1.5-flash")
        )
    else:
        PROVIDER = "stub"


def _extract_json(text: str) -> Dict[str, Any]:
    """Best-effort JSON extraction from an LLM response."""
    text = text.strip()
    # strip ```json fences
    fence = re.search(r"```(?:json)?\s*(\{.*?\}|\[.*?\])\s*```", text, re.S)
    if fence:
        text = fence.group(1)
    # try direct
    try:
        return json.loads(text)
    except Exception:
        pass
    # find first {...} or [...] balanced block
    start = min((i for i in (text.find("{"), text.find("[")) if i >= 0),
                default=-1)
    if start >= 0:
        depth = 0
        opener = text[start]
        closer = "}" if opener == "{" else "]"
        for i in range(start, len(text)):
            if text[i] == opener:
                depth += 1
            elif text[i] == closer:
                depth -= 1
                if depth == 0:
                    return json.loads(text[start:i + 1])
    raise ValueError(f"LLM did not return JSON. Got: {text[:300]}")


def complete_json(system: str, user: str) -> Dict[str, Any]:
    """Run a deterministic completion expected to return JSON."""
    _init()
    if PROVIDER == "openai":
        model = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
        resp = _client.chat.completions.create(  # type: ignore
            model=model,
            temperature=0,
            response_format={"type": "json_object"},
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
        )
        return _extract_json(resp.choices[0].message.content or "{}")
    if PROVIDER == "gemini":
        resp = _client.generate_content(  # type: ignore
            [system, user],
            generation_config={
                "temperature": 0,
                "response_mime_type": "application/json",
            },
        )
        return _extract_json(resp.text or "{}")
    # ---- offline deterministic stub ----
    from .stub_llm import stub_response
    return stub_response(system, user)
