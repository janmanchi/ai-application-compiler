"""Stage 1: Intent Extraction."""
from __future__ import annotations
import json
from .llm_client import complete_json
from schemas.intent_schema import Intent

SYSTEM = """[STAGE:INTENT]
You are the Intent Extraction stage of an AI application compiler.
Read the user's natural-language description of an app and return STRICT JSON
matching this schema:

{
  "app_type": "string (e.g. crm, ecommerce, blog, saas, booking, lms)",
  "app_name": "string",
  "features": ["string", ...],
  "entities": [{"name": "string", "description": "string",
                "attributes": ["string", ...]}],
  "roles":    [{"name": "string", "permissions": ["string", ...]}],
  "business_requirements": ["string", ...],
  "assumptions": ["string", ...],
  "open_questions": ["string", ...]
}

Rules:
- Output ONLY JSON, no prose.
- Always include a "user" entity and an "admin" role unless explicitly excluded.
- If the prompt is vague, fill assumptions[] with what you assumed.
- Be concrete: list real entities (Product, Order, Lead, ...) not placeholders.
"""


def extract_intent(prompt: str) -> Intent:
    raw = complete_json(SYSTEM, json.dumps({"prompt": prompt}))
    return Intent(**raw)
