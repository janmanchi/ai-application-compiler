"""Deterministic offline stub for the LLM.

Produces realistic intent / design / schema outputs by parsing keywords
from the prompt. Used when no API key is configured so the pipeline can
be developed, tested, and demoed without network access.
"""
from __future__ import annotations
import re
from typing import Any, Dict, List

# ---------- shared keyword catalogues ----------
ENTITY_HINTS = {
    "user": ["user", "users", "account", "accounts", "customer", "customers",
             "member", "members", "staff", "employee", "employees"],
    "product": ["product", "products", "item", "items", "inventory", "sku"],
    "order": ["order", "orders", "purchase", "purchases", "checkout"],
    "task": ["task", "tasks", "todo", "todos", "ticket", "tickets"],
    "project": ["project", "projects"],
    "post": ["post", "posts", "article", "articles", "blog"],
    "comment": ["comment", "comments", "reply", "replies"],
    "lead": ["lead", "leads", "contact", "contacts", "crm"],
    "invoice": ["invoice", "invoices", "billing"],
    "appointment": ["appointment", "appointments", "booking", "bookings",
                    "reservation", "reservations"],
    "course": ["course", "courses", "lesson", "lessons"],
    "patient": ["patient", "patients", "medical"],
    "message": ["message", "messages", "chat", "chats"],
    "file": ["file", "files", "document", "documents", "upload"],
}

FEATURE_HINTS = {
    "auth": ["login", "signup", "auth", "register", "sign in", "sign up",
             "password"],
    "search": ["search", "filter", "query"],
    "dashboard": ["dashboard", "analytics", "report", "reports", "metrics"],
    "notifications": ["notification", "notifications", "email", "alert"],
    "payments": ["payment", "payments", "billing", "stripe", "checkout"],
    "roles": ["role", "roles", "admin", "permissions", "rbac"],
    "upload": ["upload", "files", "attachment"],
    "export": ["export", "csv", "pdf"],
}

ROLE_HINTS = ["admin", "manager", "user", "staff", "customer", "owner",
              "guest", "viewer", "editor"]

APP_TYPES = [
    ("crm", "Customer Relationship Management"),
    ("ecommerce", "E-Commerce"),
    ("blog", "Blog / CMS"),
    ("saas", "SaaS App"),
    ("booking", "Booking System"),
    ("lms", "Learning Management System"),
    ("project management", "Project Management"),
    ("todo", "Task Manager"),
    ("inventory", "Inventory System"),
    ("forum", "Discussion Forum"),
]


def _detect_app(prompt: str) -> tuple[str, str]:
    p = prompt.lower()
    for key, label in APP_TYPES:
        if key in p:
            return key, label
    if "shop" in p or "store" in p:
        return "ecommerce", "E-Commerce"
    if "manage" in p:
        return "saas", "SaaS App"
    return "saas", "Generic SaaS App"


def _detect_entities(prompt: str) -> List[str]:
    p = prompt.lower()
    found = []
    for canonical, hints in ENTITY_HINTS.items():
        if any(re.search(rf"\b{re.escape(h)}\b", p) for h in hints):
            found.append(canonical)
    if "user" not in found:
        found.insert(0, "user")
    return found


def _detect_features(prompt: str) -> List[str]:
    p = prompt.lower()
    feats = []
    for f, hints in FEATURE_HINTS.items():
        if any(h in p for h in hints):
            feats.append(f)
    if "auth" not in feats:
        feats.append("auth")
    return feats


def _detect_roles(prompt: str) -> List[str]:
    p = prompt.lower()
    roles = [r for r in ROLE_HINTS if re.search(rf"\b{r}\b", p)]
    if not roles:
        roles = ["admin", "user"]
    if "admin" not in roles:
        roles.insert(0, "admin")
    return roles


# ---------- per-stage stub generators ----------
def _intent(prompt: str) -> Dict[str, Any]:
    app_type, label = _detect_app(prompt)
    entities = _detect_entities(prompt)
    features = _detect_features(prompt)
    roles = _detect_roles(prompt)
    return {
        "app_type": app_type,
        "app_name": label,
        "features": features,
        "entities": [
            {"name": e, "description": f"{e.title()} entity",
             "attributes": ["id", "name", "created_at"]}
            for e in entities
        ],
        "roles": [{"name": r, "permissions": ["read", "write"]
                   if r == "admin" else ["read"]} for r in roles],
        "business_requirements": [
            f"Support {', '.join(features)}.",
            f"Manage entities: {', '.join(entities)}.",
        ],
        "assumptions": [
            "Single-tenant deployment.",
            "Email/password authentication unless otherwise specified.",
        ],
        "open_questions": [],
    }


def _design(intent: Dict[str, Any]) -> Dict[str, Any]:
    entities = [e["name"] for e in intent["entities"]]
    pages = [{"name": "Login", "route": "/login",
              "description": "Login page", "requires_auth": False,
              "allowed_roles": []}]
    for e in entities:
        pages.append({
            "name": f"{e.title()} List", "route": f"/{e}s",
            "description": f"List of {e}s", "requires_auth": True,
            "allowed_roles": [r["name"] for r in intent["roles"]],
        })
        pages.append({
            "name": f"{e.title()} Detail", "route": f"/{e}s/:id",
            "description": f"Detail of one {e}", "requires_auth": True,
            "allowed_roles": [r["name"] for r in intent["roles"]],
        })
    rels = []
    if "user" in entities:
        for e in entities:
            if e != "user":
                rels.append({"from_entity": "user", "to_entity": e,
                             "type": "one_to_many"})
    flows = [{"name": "Authentication",
              "steps": ["User submits credentials", "Server validates",
                        "Server issues JWT", "Client stores token"]}]
    for e in entities:
        if e == "user":
            continue
        flows.append({"name": f"CRUD {e}",
                      "steps": [f"List {e}", f"Create {e}",
                                f"Edit {e}", f"Delete {e}"]})
    return {"architecture": "client-server-rest", "pages": pages,
            "entities": entities, "relationships": rels, "flows": flows}


def _ui(design: Dict[str, Any]) -> Dict[str, Any]:
    pages = []
    # login
    pages.append({
        "name": "Login", "route": "/login",
        "components": [{
            "id": "login_form", "type": "form", "title": "Sign in",
            "entity": "user",
            "fields": [
                {"name": "email", "label": "Email", "type": "email",
                 "required": True, "options": []},
                {"name": "password", "label": "Password", "type": "password",
                 "required": True, "options": []},
            ],
            "actions": [{"label": "Sign in", "api": "auth_login",
                         "method": "POST"}],
        }],
    })
    for e in design["entities"]:
        if e == "user":
            continue
        pages.append({
            "name": f"{e.title()} List", "route": f"/{e}s",
            "components": [{
                "id": f"{e}_table", "type": "table",
                "title": f"{e.title()}s", "entity": e,
                "fields": [
                    {"name": "id", "label": "ID", "type": "text",
                     "required": False, "options": []},
                    {"name": "name", "label": "Name", "type": "text",
                     "required": False, "options": []},
                ],
                "actions": [{"label": "Create", "api": f"{e}_create",
                             "method": "POST"}],
            }],
        })
        pages.append({
            "name": f"{e.title()} Form", "route": f"/{e}s/new",
            "components": [{
                "id": f"{e}_form", "type": "form",
                "title": f"New {e.title()}", "entity": e,
                "fields": [
                    {"name": "name", "label": "Name", "type": "text",
                     "required": True, "options": []},
                ],
                "actions": [{"label": "Save", "api": f"{e}_create",
                             "method": "POST"}],
            }],
        })
    return {"pages": pages}


def _api(design: Dict[str, Any]) -> Dict[str, Any]:
    endpoints = [{
        "id": "auth_login", "method": "POST", "path": "/auth/login",
        "description": "Authenticate user", "entity": "user",
        "params": [
            {"name": "email", "type": "string", "required": True,
             "location": "body"},
            {"name": "password", "type": "string", "required": True,
             "location": "body"},
        ],
        "response_fields": ["token", "user_id"],
        "auth_required": False, "allowed_roles": [],
    }]
    for e in design["entities"]:
        if e == "user":
            continue
        endpoints.extend([
            {"id": f"{e}_list", "method": "GET", "path": f"/{e}s",
             "description": f"List {e}s", "entity": e,
             "params": [], "response_fields": ["id", "name", "created_at"],
             "auth_required": True, "allowed_roles": ["admin", "user"]},
            {"id": f"{e}_create", "method": "POST", "path": f"/{e}s",
             "description": f"Create {e}", "entity": e,
             "params": [{"name": "name", "type": "string",
                         "required": True, "location": "body"}],
             "response_fields": ["id"],
             "auth_required": True, "allowed_roles": ["admin"]},
            {"id": f"{e}_get", "method": "GET", "path": f"/{e}s/{{id}}",
             "description": f"Get one {e}", "entity": e,
             "params": [{"name": "id", "type": "integer",
                         "required": True, "location": "path"}],
             "response_fields": ["id", "name", "created_at"],
             "auth_required": True, "allowed_roles": ["admin", "user"]},
            {"id": f"{e}_update", "method": "PUT", "path": f"/{e}s/{{id}}",
             "description": f"Update {e}", "entity": e,
             "params": [
                 {"name": "id", "type": "integer", "required": True,
                  "location": "path"},
                 {"name": "name", "type": "string", "required": True,
                  "location": "body"}],
             "response_fields": ["id"],
             "auth_required": True, "allowed_roles": ["admin"]},
            {"id": f"{e}_delete", "method": "DELETE",
             "path": f"/{e}s/{{id}}",
             "description": f"Delete {e}", "entity": e,
             "params": [{"name": "id", "type": "integer",
                         "required": True, "location": "path"}],
             "response_fields": ["ok"],
             "auth_required": True, "allowed_roles": ["admin"]},
        ])
    return {"base_url": "/api", "endpoints": endpoints}


def _db(design: Dict[str, Any]) -> Dict[str, Any]:
    tables = [{
        "name": "user",
        "columns": [
            {"name": "id", "type": "INTEGER", "primary_key": True,
             "nullable": False, "unique": True, "default": None,
             "references": None},
            {"name": "email", "type": "TEXT", "primary_key": False,
             "nullable": False, "unique": True, "default": None,
             "references": None},
            {"name": "password_hash", "type": "TEXT", "primary_key": False,
             "nullable": False, "unique": False, "default": None,
             "references": None},
            {"name": "role", "type": "TEXT", "primary_key": False,
             "nullable": False, "unique": False, "default": "'user'",
             "references": None},
            {"name": "created_at", "type": "DATETIME", "primary_key": False,
             "nullable": False, "unique": False,
             "default": "CURRENT_TIMESTAMP", "references": None},
        ],
    }]
    for e in design["entities"]:
        if e == "user":
            continue
        tables.append({
            "name": e,
            "columns": [
                {"name": "id", "type": "INTEGER", "primary_key": True,
                 "nullable": False, "unique": True, "default": None,
                 "references": None},
                {"name": "name", "type": "TEXT", "primary_key": False,
                 "nullable": False, "unique": False, "default": None,
                 "references": None},
                {"name": "owner_id", "type": "INTEGER", "primary_key": False,
                 "nullable": True, "unique": False, "default": None,
                 "references": "user.id"},
                {"name": "created_at", "type": "DATETIME",
                 "primary_key": False, "nullable": False, "unique": False,
                 "default": "CURRENT_TIMESTAMP", "references": None},
            ],
        })
    return {"dialect": "sqlite", "tables": tables}


def _auth(intent: Dict[str, Any], api: Dict[str, Any]) -> Dict[str, Any]:
    roles = [r["name"] for r in intent["roles"]]
    rules = []
    for ep in api["endpoints"]:
        if ep["auth_required"]:
            rules.append({"resource": ep["id"],
                          "allowed_roles": ep["allowed_roles"] or roles})
    return {
        "method": "jwt",
        "providers": ["email_password"],
        "roles": [{"name": r,
                   "permissions": ["read", "write", "delete"]
                   if r == "admin" else ["read"]} for r in roles],
        "rules": rules,
    }


def stub_response(system: str, user: str) -> Dict[str, Any]:
    """Route based on a tag the orchestrator embeds in `system`."""
    stage = None
    for tag in ("INTENT", "DESIGN", "UI", "API", "DB", "AUTH", "REPAIR"):
        if f"[STAGE:{tag}]" in system:
            stage = tag
            break
    # The orchestrator passes the original prompt OR upstream JSON in `user`.
    import json
    payload: Dict[str, Any] = {}
    try:
        payload = json.loads(user)
    except Exception:
        payload = {"prompt": user}

    if stage == "INTENT":
        return _intent(payload.get("prompt", user))
    if stage == "DESIGN":
        return _design(payload["intent"])
    if stage == "UI":
        return _ui(payload["design"])
    if stage == "API":
        return _api(payload["design"])
    if stage == "DB":
        return _db(payload["design"])
    if stage == "AUTH":
        return _auth(payload["intent"], payload["api_schema"])
    if stage == "REPAIR":
        # repair just echoes the schema with errors noted; the heuristic
        # repair_engine performs the actual structural fixes.
        return payload.get("schema", {})
    return {}
