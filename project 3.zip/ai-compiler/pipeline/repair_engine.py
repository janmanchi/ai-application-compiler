"""Stage 5: Repair Engine.

Strategy:
  - Repairs are surgical: each validation error maps to a targeted fix
    applied to ONLY the offending layer.
  - We do NOT re-run the LLM for the whole pipeline. For structural
    issues we apply deterministic fixes; for semantic gaps we may
    re-invoke the relevant schema_generator function with the failing
    layer rebuilt against the OTHER layers as authoritative context.

Each repair is logged into repair_logs so the caller can audit what
changed and why.
"""
from __future__ import annotations
from typing import List, Dict, Any, Tuple

from schemas.design_schema import Design
from schemas.ui_schema import UISchema, UIPage
from schemas.api_schema import APISchema, APIEndpoint
from schemas.db_schema import DBSchema, Table, Column, SQL_TYPES
from schemas.auth_schema import AuthSchema, AuthRole


def _log(logs: List[dict], layer: str, action: str, detail: str):
    logs.append({"layer": layer, "action": action, "detail": detail})


def repair(
    design: Design, ui: UISchema, api: APISchema, db: DBSchema,
    auth: AuthSchema, errors: List[Dict[str, Any]]
) -> Tuple[Design, UISchema, APISchema, DBSchema, AuthSchema, List[dict]]:
    logs: List[dict] = []
    db_tables = {t.name: t for t in db.tables}

    for err in errors:
        layer, kind, detail = err["layer"], err["type"], err["detail"]

        # --- DB layer ---------------------------------------------------
        if layer == "db_schema" and kind == "missing_pk":
            tname = detail.split()[1]
            t = db_tables.get(tname)
            if t:
                t.columns.insert(0, Column(name="id", type="INTEGER",
                    primary_key=True, nullable=False, unique=True))
                _log(logs, "db_schema", "add_pk",
                     f"Added INTEGER PK 'id' to table {tname}")

        elif layer == "db_schema" and kind == "bad_type":
            # Replace unknown type with TEXT
            for t in db.tables:
                for c in t.columns:
                    if c.type.upper() not in SQL_TYPES:
                        old = c.type
                        c.type = "TEXT"
                        _log(logs, "db_schema", "coerce_type",
                             f"{t.name}.{c.name}: {old} -> TEXT")

        elif layer == "db_schema" and kind == "bad_fk":
            for t in db.tables:
                for c in t.columns:
                    if c.references and (
                        "." not in c.references
                        or c.references.split(".")[0] not in db_tables
                    ):
                        _log(logs, "db_schema", "drop_fk",
                             f"Dropped invalid FK {t.name}.{c.name} -> {c.references}")
                        c.references = None

        # --- API <-> DB -------------------------------------------------
        elif layer == "api_schema" and kind == "entity_missing_in_db":
            # Create the missing table
            ent = detail.split("'")[1]
            if ent not in db_tables:
                new_table = Table(name=ent, columns=[
                    Column(name="id", type="INTEGER", primary_key=True,
                           nullable=False, unique=True),
                    Column(name="name", type="TEXT", nullable=False),
                    Column(name="created_at", type="DATETIME",
                           nullable=False, default="CURRENT_TIMESTAMP"),
                ])
                db.tables.append(new_table)
                db_tables[ent] = new_table
                _log(logs, "db_schema", "create_table",
                     f"Auto-created table '{ent}' to satisfy API")

        # --- UI <-> API/DB ---------------------------------------------
        elif layer == "ui_schema" and kind == "action_api_missing":
            # Drop the broken action
            missing_id = detail.split("->")[-1].strip().split()[0]
            for p in ui.pages:
                for c in p.components:
                    before = len(c.actions)
                    c.actions = [a for a in c.actions if a.api != missing_id]
                    if len(c.actions) != before:
                        _log(logs, "ui_schema", "drop_action",
                             f"Removed action -> {missing_id} from {c.id}")

        elif layer == "ui_schema" and kind == "component_entity_missing":
            ent = detail.split("'")[1]
            # Either add the table or clear the entity binding
            if ent not in db_tables:
                db.tables.append(Table(name=ent, columns=[
                    Column(name="id", type="INTEGER", primary_key=True,
                           nullable=False, unique=True),
                    Column(name="name", type="TEXT", nullable=False),
                ]))
                db_tables[ent] = db.tables[-1]
                _log(logs, "db_schema", "create_table",
                     f"Auto-created table '{ent}' to satisfy UI component")

        # --- Auth -------------------------------------------------------
        elif layer == "auth_schema" and kind == "role_missing":
            role = detail.split("'")[1]
            if role not in {r.name for r in auth.roles}:
                auth.roles.append(AuthRole(name=role, permissions=["read"]))
                _log(logs, "auth_schema", "add_role",
                     f"Added missing role '{role}'")

        elif layer == "auth_schema" and kind == "rule_resource_missing":
            missing = detail.split("->")[-1].strip().split()[0]
            before = len(auth.rules)
            auth.rules = [r for r in auth.rules if r.resource != missing]
            if len(auth.rules) != before:
                _log(logs, "auth_schema", "drop_rule",
                     f"Dropped auth rule for missing resource {missing}")

        else:
            _log(logs, layer, "noop",
                 f"No automatic repair for {kind}: {detail}")

    return design, ui, api, db, auth, logs
