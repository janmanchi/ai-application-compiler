"""Stage 4: Validator.

Performs:
  - Pydantic structural validation (already done at construction time
    by the generators; we re-run a defensive .model_validate here).
  - Cross-layer consistency:
      * Every API endpoint's entity must be a DB table.
      * Every API param/response field should correspond to a DB column
        (when entity is set).
      * Every UI action.api must reference an existing API endpoint id.
      * Every UI component.entity must be a DB table.
      * Every page in design must be reachable from UI (or auth-only).
      * Every auth rule must reference an existing API endpoint and only
        roles that exist in the auth schema.
      * Every role used in API endpoints must exist in auth schema.
"""
from __future__ import annotations
from typing import Dict, List, Any
from pydantic import ValidationError

from schemas.design_schema import Design
from schemas.ui_schema import UISchema
from schemas.api_schema import APISchema
from schemas.db_schema import DBSchema, SQL_TYPES
from schemas.auth_schema import AuthSchema


class ValidationReport(dict):
    @property
    def ok(self) -> bool:
        return not self.get("errors")


def _structural(report: Dict[str, Any], name: str, model, data):
    try:
        model.model_validate(data if isinstance(data, dict) else data.model_dump())
    except ValidationError as e:
        report["errors"].append({"layer": name, "type": "structural",
                                 "detail": e.errors()})


def validate_all(design: Design, ui: UISchema, api: APISchema,
                 db: DBSchema, auth: AuthSchema) -> ValidationReport:
    report = ValidationReport(errors=[], warnings=[], checks=[])
    # 1. structural
    _structural(report, "design", Design, design)
    _structural(report, "ui_schema", UISchema, ui)
    _structural(report, "api_schema", APISchema, api)
    _structural(report, "db_schema", DBSchema, db)
    _structural(report, "auth_schema", AuthSchema, auth)

    db_tables: Dict[str, set] = {
        t.name: {c.name for c in t.columns} for t in db.tables
    }
    api_ids = {ep.id for ep in api.endpoints}
    auth_roles = {r.name for r in auth.roles}

    # 2. DB column type sanity
    for t in db.tables:
        if not any(c.primary_key for c in t.columns):
            report["errors"].append({"layer": "db_schema",
                "type": "missing_pk", "detail": f"Table {t.name} has no PK"})
        for c in t.columns:
            if c.type.upper() not in SQL_TYPES:
                report["errors"].append({"layer": "db_schema",
                    "type": "bad_type",
                    "detail": f"{t.name}.{c.name} type {c.type} invalid"})
            if c.references:
                if "." not in c.references:
                    report["errors"].append({"layer": "db_schema",
                        "type": "bad_fk",
                        "detail": f"{t.name}.{c.name} references {c.references}"})
                else:
                    ft, fc = c.references.split(".", 1)
                    if ft not in db_tables or fc not in db_tables[ft]:
                        report["errors"].append({"layer": "db_schema",
                            "type": "bad_fk",
                            "detail": f"{t.name}.{c.name} -> {c.references} missing"})

    # 3. API <-> DB consistency
    for ep in api.endpoints:
        if ep.entity and ep.entity not in db_tables:
            report["errors"].append({"layer": "api_schema",
                "type": "entity_missing_in_db",
                "detail": f"Endpoint {ep.id} entity '{ep.entity}' missing"})
            continue
        if ep.entity:
            cols = db_tables[ep.entity]
            for f in ep.response_fields:
                if f not in cols and f not in {"ok", "token", "user_id"}:
                    report["warnings"].append({"layer": "api_schema",
                        "type": "response_field_unknown",
                        "detail": f"{ep.id}: response '{f}' not in {ep.entity}"})

    # 4. UI <-> API and UI <-> DB
    for page in ui.pages:
        for comp in page.components:
            if comp.entity and comp.entity not in db_tables:
                report["errors"].append({"layer": "ui_schema",
                    "type": "component_entity_missing",
                    "detail": f"{comp.id} entity '{comp.entity}' missing"})
            for act in comp.actions:
                if act.api not in api_ids:
                    report["errors"].append({"layer": "ui_schema",
                        "type": "action_api_missing",
                        "detail": f"{comp.id} action -> {act.api} missing"})

    # 5. Auth consistency
    for ep in api.endpoints:
        for r in ep.allowed_roles:
            if r not in auth_roles:
                report["errors"].append({"layer": "auth_schema",
                    "type": "role_missing",
                    "detail": f"API {ep.id} uses role '{r}' not in auth"})
    for rule in auth.rules:
        if rule.resource not in api_ids:
            report["errors"].append({"layer": "auth_schema",
                "type": "rule_resource_missing",
                "detail": f"Auth rule -> {rule.resource} missing"})
        for r in rule.allowed_roles:
            if r not in auth_roles:
                report["errors"].append({"layer": "auth_schema",
                    "type": "role_missing",
                    "detail": f"Auth rule {rule.resource} role '{r}'"})

    # 6. Design pages should have matching UI routes (warning only)
    ui_routes = {p.route for p in ui.pages}
    for p in design.pages:
        # design may use :id placeholders; collapse for compare
        normalized = p.route.split(":")[0].rstrip("/")
        if not any(r.startswith(normalized) for r in ui_routes):
            report["warnings"].append({"layer": "ui_schema",
                "type": "design_page_unbuilt",
                "detail": f"Design page {p.name} ({p.route}) has no UI"})

    report["checks"] = [
        "structural", "db_types_and_fks", "api_db_consistency",
        "ui_api_db_consistency", "auth_roles_and_rules", "design_ui_coverage",
    ]
    return report
