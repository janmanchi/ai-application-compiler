const $ = (id) => document.getElementById(id);

function syntax(obj) {
  let json = JSON.stringify(obj, null, 2);
  json = json.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  return json.replace(
    /("(\\u[a-zA-Z0-9]{4}|\\[^u]|[^\\"])*"(\s*:)?|\b(true|false|null)\b|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)/g,
    (m) => {
      let cls = "json-num";
      if (/^"/.test(m)) cls = /:$/.test(m) ? "json-key" : "json-str";
      else if (/true|false|null/.test(m)) cls = "json-bool";
      return '<span class="' + cls + '">' + m + "</span>";
    },
  );
}

function setBadge(id, status) {
  const b = $(id);
  b.className = "badge " + status;
  b.textContent = status.toUpperCase();
}

async function generate() {
  const prompt = $("prompt").value.trim();
  if (!prompt) return;
  const btn = $("go");
  btn.disabled = true; btn.textContent = "Compiling...";
  $("empty").style.display = "none";
  $("grid").style.display = "grid";
  for (const id of ["r-intent","r-design","r-ui","r-api","r-db","r-auth","r-val","r-rep","r-rt"])
    $(id).innerHTML = "...";

  try {
    const r = await fetch("/generate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ prompt }),
    });
    const data = await r.json();
    if (data.error) throw new Error(data.error);

    $("r-intent").innerHTML = syntax(data.intent);
    $("r-design").innerHTML = syntax(data.design);
    $("r-ui").innerHTML     = syntax(data.ui_schema);
    $("r-api").innerHTML    = syntax(data.api_schema);
    $("r-db").innerHTML     = syntax(data.db_schema);
    $("r-auth").innerHTML   = syntax(data.auth_schema);
    $("r-val").innerHTML    = syntax(data.validation);
    $("r-rep").innerHTML    = syntax(data.repair_logs);
    $("r-rt").innerHTML     = syntax(data.runtime_results);

    setBadge("b-val", data.validation.errors.length ? "fail" : "ok");
    setBadge("b-rep", data.repair_logs.length ? "warn" : "ok");
    setBadge("b-rt",  data.runtime_results.status === "PASS" ? "ok" : "fail");

    $("metrics").style.display = "block";
    $("m-latency").textContent = data.metrics.latency_ms + " ms";
    $("m-retries").textContent = data.metrics.retries;
    $("m-repairs").textContent = data.metrics.repair_count;
    $("m-valid").textContent   = data.metrics.validation_ok ? "PASS" : "FAIL";
    $("m-runtime").textContent = data.metrics.runtime_status;
  } catch (e) {
    alert("Compilation failed: " + e.message);
  } finally {
    btn.disabled = false; btn.textContent = "Generate";
  }
}

$("go").addEventListener("click", generate);
document.querySelectorAll(".examples button").forEach((b) =>
  b.addEventListener("click", () => { $("prompt").value = b.dataset.ex; }),
);
