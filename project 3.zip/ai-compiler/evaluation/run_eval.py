"""Evaluation harness.

Runs the full pipeline against every prompt in dataset.json and prints
aggregate metrics. Use:
    python -m evaluation.run_eval
"""
from __future__ import annotations
import json
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from orchestrator import run_pipeline  # noqa: E402


def main() -> None:
    ds = json.loads((ROOT / "evaluation" / "dataset.json").read_text())
    all_prompts = [("normal", p) for p in ds["normal"]] + \
                  [("edge", p) for p in ds["edge_cases"]]

    summary = {"total": 0, "success": 0, "runtime_pass": 0,
               "total_retries": 0, "total_repairs": 0, "latency_ms": 0}
    rows = []
    for kind, prompt in all_prompts:
        t0 = time.time()
        try:
            r = run_pipeline(prompt)
            ok = r["metrics"]["validation_ok"]
            rt = r["metrics"]["runtime_status"]
            rows.append({"kind": kind, "ok": ok, "runtime": rt,
                         "retries": r["metrics"]["retries"],
                         "repairs": r["metrics"]["repair_count"],
                         "latency_ms": r["metrics"]["latency_ms"],
                         "prompt": prompt[:60]})
            summary["total"] += 1
            summary["success"] += int(ok)
            summary["runtime_pass"] += int(rt == "PASS")
            summary["total_retries"] += r["metrics"]["retries"]
            summary["total_repairs"] += r["metrics"]["repair_count"]
            summary["latency_ms"] += r["metrics"]["latency_ms"]
        except Exception as e:
            rows.append({"kind": kind, "ok": False, "runtime": "ERROR",
                         "error": str(e), "prompt": prompt[:60]})
            summary["total"] += 1
            summary["latency_ms"] += int((time.time() - t0) * 1000)

    print("=== Per-prompt ===")
    for r in rows:
        print(json.dumps(r))
    print("\n=== Summary ===")
    summary["success_rate"] = round(
        summary["success"] / summary["total"], 3) if summary["total"] else 0
    summary["runtime_pass_rate"] = round(
        summary["runtime_pass"] / summary["total"], 3) if summary["total"] else 0
    summary["avg_latency_ms"] = round(
        summary["latency_ms"] / summary["total"]) if summary["total"] else 0
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
